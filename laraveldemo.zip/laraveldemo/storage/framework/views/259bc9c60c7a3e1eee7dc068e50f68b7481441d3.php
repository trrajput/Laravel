    
<?php $__env->startSection('content'); ?>
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css" rel="stylesheet">  
   
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Filter </div>

                <div class="card-body">
                <div class="row" >
                    <label class="col-md-3 offset-3 text-right">Select Creation Date: </label>
                    <div class="col-md-4 ">
                        <input type="text" class="form-control datepicker " id="date" name="date" placeholder="dd-mm-yyyy" autocomplete="off" >
                     </div>
                     <div class="col-md-2 ">
                        <button class="btn btn-default filter">Filter</button>   
                    </div>
                </div>
                </div>
            </div>
            <br>   
            <div class="card">
                <div class="card-header">Newest Blogs</div>

                <div class="card-body articles">
                 <?php echo $__env->make('articles.load', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <?php echo $__env->make('articles.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
</div>
<script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
   <!-- Bootstrap Date-Picker Plugin -->
   <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
  
<script type="text/javascript">
  
    jQuery(document).ready(function($) {
        $('.datepicker').datepicker({
            format: "dd-mm-yyyy",
            todayHighlight: true,
        });
    });
    $(function() {
        /*==== Pagination using Ajax =====*/
        /*$('body').on('click', '.pagination a', function(e) {
            
            e.preventDefault();

            var url = $(this).attr('href');
            getArticles(url);
            window.history.pushState("", "", url);
        });
        */
        /*==== End Pagination using Ajax =====*/
        /*==== Date Filter =====*/
        $('body').on('click', '.filter', function(e) {
            if($.trim($('#date').val())!=''){
            e.preventDefault();

            var url = $(this).attr('href');
            getArticles('<?php echo e(route("articles.index")); ?>');
            window.history.pushState("", "", url);
        }else{
            alert('Please select a date');
        }
        }); 
       
        function getArticles(url) {
            $.ajax({
                url:url,
                data:{
                    date:$('#date').val(),
                },
            }).done(function (data) {
                $('.articles').html(data);
            }).fail(function () {
                alert('Articles could not be loaded.');
            });
        }
        /*==== End Date Filter =====*/
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Add new blog</div>

                <div class="card-body">

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('articles.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        Article title*:
                        <input type="text" name="title" class="form-control" value="<?php echo e(old('title')); ?>" />
                        <br />

                        Article text*:
                        <textarea name="article_text" class="form-control" rows="10"><?php echo e(old('article_text')); ?></textarea>
                        <br />

                        Categories:
                        <br />
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <input type="checkbox" name="categories[]" value="<?php echo e($category->id); ?>" /> <?php echo e($category->name); ?>

                            <br />
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <br />

                        Tags (comma-separated):
                        <input type="text" name="tags" class="form-control" />
                        <br />

                      <!--  Blog image:
                        <br />
                        <input type="file" name="main_image" />
                        <br /> --><br />

                        <input type="submit" value=" Save blog " class="btn btn-primary" />

                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><h1><?php echo e($article->title); ?></h1></div>

                <div class="card-body">

                    <p>
                        <img src="<?php echo e($article->getFirstMediaUrl('main_images', 'main')); ?>" />
                    </p>

                    <p>
                        <b>Author:</b> <?php echo e($article->author->name); ?>

                    </p>
                    <p>
                        <b>Categories:</b>
                        <?php echo $article->categories_links; ?>

                    </p>
                    <p>
                        <b>Tags:</b>
                        <?php echo $article->tags_links; ?>

                    </p>

                    <p><?php echo nl2br($article->article_text); ?></p>

                </div>
            </div>
        </div>
        <div class="col-md-4">
            <?php echo $__env->make('articles.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="row">
                        <!-- <div class="col-md-4">
                            <img src="<?php echo e($article->getFirstMediaUrl('main_images', 'thumb')); ?>" />
                        </div> -->
                        <div class="col-md-8 offset-1">
                            <a href="<?php echo e(route('articles.show', $article->id)); ?>"><h2><?php echo e($article->title); ?></h2></a>
                            <p>
                                <b>Author:</b> <?php echo e($article->author->name); ?>

                            </p>
                            <p>
                                <b>Categories:</b>
                                <?php echo $article->categories_links; ?>

                            </p>
                            <p>
                                <b>Tags:</b>
                                <?php echo $article->tags_links; ?>

                            </p>
                            <p><?php echo e(substr($article->article_text, 0, 200)); ?>...
                                <a href="<?php echo e(route('articles.show', $article->id)); ?>">Read full article</a></p>
                        </div>
                    </div>
                    <hr />
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        No articles yet.
                    <?php endif; ?>

                    <?php echo e($articles->links()); ?>

